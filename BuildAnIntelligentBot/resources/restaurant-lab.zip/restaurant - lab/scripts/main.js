var SlideEffect = "slide";

$(document).ready(function() {

  if (SlideEffect === "slide") {
    $('.main-slider').slick({
      arrows: false
    });
  } else {
    if (SlideEffect === "fade") {
      $('.main-slider').slick({
        dots: true,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear'
      });
    }
  }

  $('.slider-leftbutton').click(function() {
    $('.main-slider').slick('slickPrev');
  });
  $('.slider-rightbutton').click(function() {
    $('.main-slider').slick('slickNext');
  });

  setInterval(function() {
    $('.main-slider').slick('slickNext');
  }, 6000);
});
